<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
    
        <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
        <link  href="style_header2.css" rel="stylesheet">
        <script src="js/header.js"></script>
        

        <title>Goélands Breizh</title>
    </head>
    <div id="page_accueil">
        <body>
            <header>
              <?php 
                include("header2.php"); 
              ?>
            </header>

            <section class="container">
                <p>

                Votre message à bien était transmis, merci pour votre message.
                
                </p>

            </section>

        </body>
    </div>
    
</html>
