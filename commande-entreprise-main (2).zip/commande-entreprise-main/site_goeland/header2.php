<div class="container-fluid" >
  <nav class="navbar navbar-inverse" >
    <div class="container-fluid" >
      <ul class="nav navbar-nav" >
        <li class="header"><a id="len1" class="hoverable"  href="accueil_goe.php">Accueil</a></li>
        <li class="header"><a id="len2" class="hoverable"  href="prediction.php">Prédiction</a></li>
        <li class="header"><a id="len3" class="hoverable"  href="notebooks.php">Notebooks</a></li>
        <li class="header"><a id="len4" class="hoverable"  href="contact.php">Contact</a></li>
        <li class="header"><a id="len5" class="hoverable"  href="connexion.php">Connexion</a></li>
      </ul>
    </div>
  </nav>
 